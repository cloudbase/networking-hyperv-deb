============
Installation
============

At the command line::

    $ pip install networking-hyperv

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv networking-hyperv
    $ pip install networking-hyperv
